namespace WinFormsApp12
{
    public partial class Form1 : Form
    {
        private int moveCounter = 0;
        private Button[] buttons;

        public Form1()
        {
            InitializeComponent();
            InitializeButtons();
        }

        private void InitializeButtons()
        {
            buttons = new Button[] { btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9 };

            foreach (Button button in buttons)
            {
                button.Click += Button_Click;
            }
        }

        private void Button_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            clickedButton.Text = GetCurrentPlayerSymbol();
            clickedButton.Enabled = false;
            moveCounter++;

            if (HasWinner())
            {
                MessageBox.Show($"{GetCurrentPlayerSymbol()} lost");
                ResetGame();
            }
            else if (IsTie())
            {
                MessageBox.Show("It's a Tie!");
                ResetGame();
            }
        }

        private string GetCurrentPlayerSymbol()
        {
            return (moveCounter % 2 == 0) ? "X" : "O";
        }

        private bool HasWinner()
        {
            return CheckRow(btn_1, btn_2, btn_3) || CheckRow(btn_4, btn_5, btn_6) || CheckRow(btn_7, btn_8, btn_9) ||   // Horizontal lines
                   CheckRow(btn_1, btn_4, btn_7) || CheckRow(btn_2, btn_5, btn_8) || CheckRow(btn_3, btn_6, btn_9) ||   // Vertical lines
                   CheckRow(btn_1, btn_5, btn_9) || CheckRow(btn_3, btn_5, btn_7);                                     // Diagonals
        }

        private bool CheckRow(Button b1, Button b2, Button b3)
        {
            return b1.Text == b2.Text && b2.Text == b3.Text && b1.Text != "";
        }

        private bool IsTie()
        {
            return buttons.All(button => !button.Enabled);
        }

        private void ResetGame()
        {
            moveCounter = 0;

            foreach (Button button in buttons)
            {
                button.Enabled = true;
                button.Text = string.Empty;
            }
        }
    }
}
