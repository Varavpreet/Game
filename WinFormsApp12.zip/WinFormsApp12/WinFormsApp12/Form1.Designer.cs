﻿namespace WinFormsApp12
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            btn_9 = new Button();
            btn_8 = new Button();
            btn_7 = new Button();
            btn_6 = new Button();
            btn_5 = new Button();
            btn_4 = new Button();
            btn_3 = new Button();
            btn_2 = new Button();
            btn_1 = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Controls.Add(btn_9, 2, 2);
            tableLayoutPanel1.Controls.Add(btn_8, 1, 2);
            tableLayoutPanel1.Controls.Add(btn_7, 0, 2);
            tableLayoutPanel1.Controls.Add(btn_6, 2, 1);
            tableLayoutPanel1.Controls.Add(btn_5, 1, 1);
            tableLayoutPanel1.Controls.Add(btn_4, 0, 1);
            tableLayoutPanel1.Controls.Add(btn_3, 2, 0);
            tableLayoutPanel1.Controls.Add(btn_2, 1, 0);
            tableLayoutPanel1.Controls.Add(btn_1, 0, 0);
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Size = new Size(300, 300);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // btn_9
            // 
            btn_9.BackColor = SystemColors.ButtonHighlight;
            btn_9.Dock = DockStyle.Fill;
            btn_9.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_9.ForeColor = SystemColors.ActiveCaption;
            btn_9.Location = new Point(203, 203);
            btn_9.Name = "btn_9";
            btn_9.Size = new Size(94, 94);
            btn_9.TabIndex = 8;
            btn_9.UseVisualStyleBackColor = false;
            // 
            // btn_8
            // 
            btn_8.Dock = DockStyle.Fill;
            btn_8.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_8.ForeColor = SystemColors.ActiveCaption;
            btn_8.Location = new Point(103, 203);
            btn_8.Name = "btn_8";
            btn_8.Size = new Size(94, 94);
            btn_8.TabIndex = 7;
            btn_8.UseVisualStyleBackColor = true;
            // 
            // btn_7
            // 
            btn_7.Dock = DockStyle.Fill;
            btn_7.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_7.ForeColor = SystemColors.ActiveCaption;
            btn_7.Location = new Point(3, 203);
            btn_7.Name = "btn_7";
            btn_7.Size = new Size(94, 94);
            btn_7.TabIndex = 6;
            btn_7.UseVisualStyleBackColor = true;
            // 
            // btn_6
            // 
            btn_6.Dock = DockStyle.Fill;
            btn_6.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_6.ForeColor = SystemColors.ActiveCaption;
            btn_6.Location = new Point(203, 103);
            btn_6.Name = "btn_6";
            btn_6.Size = new Size(94, 94);
            btn_6.TabIndex = 5;
            btn_6.UseVisualStyleBackColor = true;
            // 
            // btn_5
            // 
            btn_5.Dock = DockStyle.Fill;
            btn_5.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_5.ForeColor = SystemColors.ActiveCaption;
            btn_5.Location = new Point(103, 103);
            btn_5.Name = "btn_5";
            btn_5.Size = new Size(94, 94);
            btn_5.TabIndex = 4;
            btn_5.UseVisualStyleBackColor = true;
            // 
            // btn_4
            // 
            btn_4.Dock = DockStyle.Fill;
            btn_4.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_4.ForeColor = SystemColors.ActiveCaption;
            btn_4.Location = new Point(3, 103);
            btn_4.Name = "btn_4";
            btn_4.Size = new Size(94, 94);
            btn_4.TabIndex = 3;
            btn_4.UseVisualStyleBackColor = true;
            // 
            // btn_3
            // 
            btn_3.Dock = DockStyle.Fill;
            btn_3.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_3.ForeColor = SystemColors.ActiveCaption;
            btn_3.Location = new Point(203, 3);
            btn_3.Name = "btn_3";
            btn_3.Size = new Size(94, 94);
            btn_3.TabIndex = 2;
            btn_3.UseVisualStyleBackColor = true;
            // 
            // btn_2
            // 
            btn_2.Dock = DockStyle.Fill;
            btn_2.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_2.ForeColor = SystemColors.ActiveCaption;
            btn_2.Location = new Point(103, 3);
            btn_2.Name = "btn_2";
            btn_2.Size = new Size(94, 94);
            btn_2.TabIndex = 1;
            btn_2.UseVisualStyleBackColor = true;
            // 
            // btn_1
            // 
            btn_1.Dock = DockStyle.Fill;
            btn_1.Font = new Font("Segoe UI", 42F, FontStyle.Bold);
            btn_1.ForeColor = SystemColors.ActiveCaption;
            btn_1.Location = new Point(3, 3);
            btn_1.Name = "btn_1";
            btn_1.Size = new Size(94, 94);
            btn_1.TabIndex = 0;
            btn_1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(303, 301);
            Controls.Add(tableLayoutPanel1);
            Name = "Form1";
            Text = "Form1";
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button btn_1;
        private Button btn_6;
        private Button btn_5;
        private Button btn_4;
        private Button btn_3;
        private Button btn_2;
        private Button btn_8;
        private Button btn_7;
        private Button btn_9;
    }
}
